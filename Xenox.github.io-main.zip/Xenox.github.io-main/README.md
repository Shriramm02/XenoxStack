# Xenyxeno.github.io

#GITHUB HOSTED WEBSITE LINK 

https://manutomar46.github.io/Xenyxeno.github.io/log.html

#HOMEPAGE
<img width="1512" alt="Screenshot 2022-10-19 at 9 30 14 PM" src="https://user-images.githubusercontent.com/63242177/196745079-d575e395-1f09-4066-92df-61a7ba780451.png">


#LOGIN
<img width="1512" alt="Screenshot 2022-10-19 at 9 31 38 PM" src="https://user-images.githubusercontent.com/63242177/196745106-d9ce48cb-136a-4e21-93a3-70c9d9b03de7.png">


#CONTACT US
<img width="1512" alt="Screenshot 2022-10-19 at 9 31 00 PM" src="https://user-images.githubusercontent.com/63242177/196745123-428aa8f7-2a2b-424e-a1b6-255a93b58ed7.png">
